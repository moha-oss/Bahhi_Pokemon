package com.example.pokemon

import android.location.Location

class Pokemon {
    var name:String?=null
    var image:Int?=null
    var power:Double?=null
    var location:Location?=null
    var isCatch:Boolean?=false

    constructor(image: Int?, name: String?, power: Double?, lat:Double, long:Double) {
        this.name = name
        this.image = image
        this.power = power
        this.location!!.latitude = lat
        this.location!!.longitude = long
    }

}