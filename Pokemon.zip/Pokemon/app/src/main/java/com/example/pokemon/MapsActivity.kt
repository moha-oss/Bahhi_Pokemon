package com.example.pokemon

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.ActivityCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.pokemon.databinding.ActivityMapsBinding
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding

    //oncreate
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        loadPokemons()
        chequePermession()
    }

    //CheauePermission
    val acceslocation = 123
    fun chequePermession(){
        if(Build.VERSION.SDK_INT >= 23) {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(
                    arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                    acceslocation
                )
                return
            }
        }
        getUserLocqtion()
    }


    //onRequestPernission
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode){
            acceslocation ->{
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    getUserLocqtion()
                }else{
                    Toast.makeText(this, " location access is deny ", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    //getUserLocation
    @SuppressLint("ServiceCast")
    fun getUserLocqtion(){
        Toast.makeText(this, " location access now ", Toast.LENGTH_LONG).show()
        val mypostition = Mylocation()
        val locationmanager = getSystemService(Context.LOCALE_SERVICE) as LocationManager
        locationmanager.requestLocationUpdates(LocationManager.GPS_PROVIDER,3,3f,mypostition)
        val mythread = myThread()
        mythread.start()
    }


    //OnMapReady
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add a marker in Sydney and move the camera
        val sydney = LatLng(31.630000, 	-8.008889)
        mMap.addMarker(MarkerOptions()
            .position(sydney)
            .title("Me")
            .icon(BitmapDescriptorFactory.fromResource(R.drawable.mario))
            .snippet("Her is my location")
        )
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney,14f))
    }


    // class Mylocation
    var mylocation:Location? = null
    inner class Mylocation : LocationListener {
        constructor(){
            mylocation = Location("me")
            mylocation!!.longitude = 0.0
            mylocation!!.latitude = 0.0
        }
        override fun onLocationChanged(p0: Location) {
            mylocation = p0
        }
    }


    //Thread
    var oldlocation:Location?=null
    inner class myThread :Thread{
        constructor():super(){

        }
        override fun run() {
            while (true){
                try {
                    if (oldlocation!!.distanceTo(mylocation!!) == 0f){
                        continue
                    }
                    runOnUiThread {
                        mMap!!.clear()
                        val myl = LatLng(mylocation!!.latitude, mylocation!!.longitude)
                        mMap.addMarker(MarkerOptions()
                            .position(myl)
                            .title("Me")
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.mario))
                            .snippet("Her is my location")
                        )
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(myl,14f))

                        for(p in pokemoms){
                            var newPokemon = p
                            if (p.isCatch == false){
                                val pl = LatLng(p.location!!.latitude, 	p.location!!.longitude)
                                mMap.addMarker(MarkerOptions()
                                    .position(pl)
                                    .title(p.name)
                                    .icon(BitmapDescriptorFactory.fromResource(p.image!!))
                                    .snippet("power: "+p.power)
                                )
                                if (mylocation!!.distanceTo(p.location!!)<2){
                                    p.isCatch = true
                                    myPower = myPower!! + p.power!!
                                    Toast.makeText(applicationContext, " You catch a pokemon your new power is: " + myPower,
                                        Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                    Thread.sleep(1000)
                }catch (ex : Exception){}
            }
        }
    }


    //Pokemons
    var myPower:Double?=10.1
    var pokemoms = ArrayList<Pokemon>()
    fun loadPokemons(){
        pokemoms.add(Pokemon(R.drawable.p1,"pokemon1",10.0,31.614240,-8.020610))
        pokemoms.add(Pokemon(R.drawable.p2,"pokemon2",30.0,31.617707,-8.009098))
        pokemoms.add(Pokemon(R.drawable.p3,"pikatcho",98.0,31.626276,-7.983292))
    }
}